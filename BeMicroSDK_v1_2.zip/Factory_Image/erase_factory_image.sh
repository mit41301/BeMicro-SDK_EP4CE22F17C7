#
# Download the sof in preparation for the nios2-flash-programmer
#
nios2-configure-sof '--cable=USB-Blaster on localhost [USB-0]'

#
# Programming File: "BeMicroII_epcs_flash_controller.flash" To Device: epcs_flash_controller
#
nios2-flash-programmer --erase-all --base=0xa003800 --epcs --sidp=0x80002A8 --id=0x6060D7D5 --timestamp=1287701530 --device=1 --instance=0 '--cable=USB-Blaster on localhost [USB-0]' 


