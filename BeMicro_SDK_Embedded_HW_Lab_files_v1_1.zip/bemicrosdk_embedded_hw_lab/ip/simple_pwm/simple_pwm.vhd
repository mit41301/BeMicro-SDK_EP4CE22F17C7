library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

entity simple_pwm is
port (
	-- global signals (clock and reset)
	clk : in std_logic;
	reset : in std_logic;
	
	-- Avalon-MM slave generic signals
	-- note that there is no address as this component
	-- only has 1 read and write register
	chipselect : in std_logic;
	
	-- Avalon write interface
	write : in std_logic;
	writedata : in std_logic_vector (31 downto 0);
	
	-- Avalon read interface
	read : in std_logic;
	readdata : out std_logic_vector (31 downto 0);
	
	-- External signals
	pwm_out : out std_logic
	);
end simple_pwm;

architecture behavior of simple_pwm is

signal count : std_logic_vector (9 downto 0);
signal duty_reg : std_logic_vector (9 downto 0);

begin

-- describe a standard 8 bit free running counter with reset
counter: process (clk, reset)
begin
	if reset = '1' then
		count <= (others => '0');
	elsif rising_edge (clk) then
		count <= count + 1;
	end if;
end process;

-- describe a register that latches data to and from the Avalon bus
-- this requires chipselect and write to be active for the write
-- to occur
reg: process (clk, reset)
begin
	if reset = '1' then
		duty_reg <= (others => '0');
	elsif rising_edge (clk) then
		if write = '1' and chipselect = '1' then
			duty_reg <= writedata(9 downto 0);
		end if;
		
		if read = '1' and chipselect = '1' then
			readdata(9 downto 0) <= duty_reg;
			readdata(31 downto 10) <= (others => '0');
		end if;
	end if;
end process;

-- generate a pwm output that is active if the value
-- in the register is greater than the value in the
-- counter
pwm_out <= '1' when duty_reg > count else '0';

end behavior;
		
	