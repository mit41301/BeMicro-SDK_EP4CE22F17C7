#
# simple_pwm_sw.tcl
#

# Create a new driver
create_driver simple_pwm_driver

# Associate it with some hardware known as "simple_pwm"
set_sw_property hw_class_name simple_pwm

# The version of this driver
set_sw_property version 1.1

# This driver may be incompatible with versions of hardware less
# than specified below. Updates to hardware and device drivers
# rendering the driver incompatible with older versions of
# hardware are noted with this property assignment.
#
# This version of the software driver is compatible with hardware 
# version 1.0 and greater.
set_sw_property min_compatible_hw_version 1.0

# Do not initialize the driver in alt_sys_init() since we do not
# have a HAL version of the driver
set_sw_property auto_initialize false

# Location in generated BSP that above sources will be copied into
set_sw_property bsp_subdirectory drivers

#
# Source file listings...
#

# Include files
add_sw_property include_source inc/simple_pwm_regs.h

# This driver supports HAL BSP (OS) type
add_sw_property supported_bsp_type HAL
add_sw_property supported_bsp_type UCOSII

# End of file
