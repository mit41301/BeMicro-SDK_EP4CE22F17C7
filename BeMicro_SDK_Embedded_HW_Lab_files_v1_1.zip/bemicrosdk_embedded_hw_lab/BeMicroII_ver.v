module BeMicroII_ver
(
   // General
   input    wire  CLK_FPGA_50M,
   input    wire  CPU_RST_N,

   // Temp. Sensor I/F
   output   wire  TEMP_CS_N,
   output   wire  TEMP_SC,       
   output   wire  TEMP_MOSI,
   input    wire  TEMP_MISO,

   // Misc
   input    wire  RECONFIG_SW1,
   input    wire  RECONFIG_SW2,
   input    wire  PBSW_N,
   output   wire  F_LED0,
   output   wire  F_LED1,
   output   wire  F_LED2,
   output   wire  F_LED3,
   output   wire  F_LED4,
   output   wire  F_LED5,
   output   wire  F_LED6,
   output   wire  F_LED7


);

//------------------------------------------------------------------------------
// Signal Declarations
//------------------------------------------------------------------------------
wire [1:0]  dipsw;
wire [7:0]  led;

wire wTEMP_MOSI;


//------------------------------------------------------------------------------
// Begin Module
//------------------------------------------------------------------------------

// Define open drain output for TEMP_MOSI
OPNDRN iTEMP_MOSI_OD (.in(wTEMP_MOSI), .out(TEMP_MOSI));


// wire up buses
assign dipsw[0] = RECONFIG_SW1;
assign dipsw[1] = RECONFIG_SW2;

assign F_LED0 = ~led[0];
assign F_LED1 = ~led[1];
assign F_LED2 = ~led[2];
assign F_LED3 = ~led[3];
assign F_LED4 = ~led[4];
assign F_LED5 = ~led[5];
assign F_LED6 = ~led[6];
assign F_LED7 = ~led[7];



wire reset_n;

reset_logic reset_logic_inst(
   .a_50_MHZ_CLK(CLK_FPGA_50M),                                                  //input
   .RESET_N(reset_n)                                                             //output
);



//SOPC system
nios2_bemicro_sopc nios2_bemicro_sopc_inst
(
   .ext_clk_50                           (CLK_FPGA_50M),                         //  input            ext_clk_50;
   .reset_n                              (reset_n),                              //  input            reset_n;

   .SCLK_from_the_temp_sense_spi         (TEMP_SC),                              //  output           SCLK_from_the_temp_sense_spi;
   .SS_n_from_the_temp_sense_spi         (TEMP_CS_N),                            //  output           SS_n_from_the_temp_sense_spi;
   .MISO_to_the_temp_sense_spi           (TEMP_MISO),                            //  input            MISO_to_the_temp_sense_spi;
   .MOSI_from_the_temp_sense_spi         (wTEMP_MOSI),                           //  output           MOSI_from_the_temp_sense_spi; 

   .in_port_to_the_dipsw_pio             (dipsw),                                //  input   [  1: 0] in_port_to_the_dipsw_pio;
   .in_port_to_the_user_pio_pushbtn      (PBSW_N),                               //  input            in_port_to_the_user_pio_pushbtn;

   .out_port_from_the_led_pio            (led[6:0]),                             //  output  [  6: 0] out_port_from_the_led_pio;

	.pwm_out_from_the_led_pwm             (led[7])											//  output           pwm_out_from_the_led_pwm;
	);

endmodule
