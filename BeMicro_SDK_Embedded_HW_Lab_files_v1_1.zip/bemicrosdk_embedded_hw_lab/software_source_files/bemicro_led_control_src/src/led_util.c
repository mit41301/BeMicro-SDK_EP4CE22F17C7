#include "system.h"
#include "alt_types.h"
#include "sys/alt_stdio.h"
#include <string.h>
#include "altera_avalon_pio_regs.h"
#include "simple_pwm_regs.h"

#include "../inc/main_includes.h"

// declare and initialize global variables for the led states and masks
volatile alt_u8  LED_STATE = 0;

volatile alt_u8  LED_MASK = 0;

// convenience routine for updating the bank of leds
void update_led(alt_u8 display_value)
{
            LED_STATE = display_value & 0xFF;
            LED_STATE &= ~LED_MASK;
            IOWR_ALTERA_AVALON_PIO_DATA(LED_PIO_BASE, LED_STATE);
}

// convenience routines for updating the pwm controlled led
void update_led_pwm()
{
  char input;
  char ch;
  int intensity;
  int i;

    //clear out the other LEDs
    update_led(0);

    alt_printf("On a scale of 0 to 9, enter the desired LED intensity\n");
    input = alt_getchar();
    alt_getchar();
    if (input == '0')
        intensity = 0;
    else if (input == '1')
        intensity = 4;
    else if (input == '2')
        intensity = 8;
    else if (input == '3')
        intensity = 16;
    else if (input == '4')
        intensity = 32;
    else if (input == '5')
        intensity = 64;
    else if (input == '6')
        intensity = 128;
    else if (input == '7')
        intensity = 256;
    else if (input == '8')
        intensity = 512;
    else if (input == '9')
        intensity = 1023;
    else {
        intensity = 0;
        alt_printf("INVALID ENTRY");
    }
    alt_printf("Setting PWM value to 0x%x  (Max value is 0x3ff)\n",intensity);
//    while ((ch = alt_getchar()) != '\n' && ch != EOF); // do this to flush the input buffer since fflush(stdin) is not recommended
    IOWR_SIMPLE_PWM(LED_PWM_BASE, intensity);
}
