
#include "alt_types.h"

#define SCAN_INTERVAL         300         // periodic scan rate in mS

typedef struct {
  volatile float value;
} TEMP_STRUCT;

void temp_sensor_init();

