#ifndef _FIR_H_
#define _FIR_H_

#define DATA_BUFFER_SIZE 1000000

#if ((DATA_BUFFER_SIZE * 3) > (8 * 1024 * 1024))
  #error "Please reduce the buffer size otherwise you will run out of memory or the test may overflow the timer"
#endif

/* The coefficients below define a 15 tap low pass filter.
 * These filters use a hanning window a sampling rate of 1.0E7 and a cutoff
 * frequency of 1.25E6 */

  #define DIVIDER_ORDER 15
  #define T 15
  short coefficients[T] = { -40, -254, -455, 0, 1699, 4450, 7093, 8191, 7093, 4450, 1699, 0, -455, -254, -40 };

/* Input data set :
 * This input contains two sine waves at high and low frequencies
 * First sine:  Amplitude = 100, Frequency = 2.5MHz
 * Second sine:  Amplitude = 1000, Frequency = 156.25kHz
 * Length is 64 since that's how many samples are in the second sine wave
 *  ROUND(100*SIN((2*PI*t)/4),0) + ROUND(1000*SIN((2*PI*t)/64),0)
                      */

#define INPUT_LENGTH 64

short input_data[INPUT_LENGTH] = {0 ,198, 195, 190, 383, 571, 556, 534, 707, 873, 831, 782, 924, 1057,
							981, 895, 1000, 1095, 981, 857, 924	, 982, 831, 673, 707, 734, 556,
							371, 383, 390, 195, -2, 0, 2, -195, -390, -383, -371, -556, -734, -707,
							-673, -831, -982, -924, -857, -981, -1095, -1000, -895, -981, -1057,
							-924, -782, -831, -873, -707, -534, -556, -571, -383, -190, -195, -198 };


void FIR_HW(short * __restrict__ input_data,
            long length,
            short * __restrict__ output_data,
            unsigned char tap_length,
            short coefA,
            short coefB,
            short coefC,
            short coefD,
            short coefE,
            short coefF,
            short coefG,
            short coefH,
            unsigned char divide_order);


void FIR_SW(short * __restrict__ input_data,
            long length,
            short * __restrict__ output_data,
            unsigned char tap_length,
            short coefA,
            short coefB,
            short coefC,
            short coefD,
            short coefE,
            short coefF,
            short coefG,
            short coefH,
            unsigned char divide_order);

#endif //_FIR_H_
