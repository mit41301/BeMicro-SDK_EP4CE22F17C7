/************************************************************************************************************************
*  File: lab2.c
*
*  Last Modified: 10/08/2010
*
*
*************************************************************************************************************************/


/*Copyright � 2006 Altera Corporation. All rights reserved.  Altera products are
protected under numerous U.S. and foreign patents, maskwork rights, copyrights and
other intellectual property laws.

This reference design file, and your use thereof, is subject to and governed by
the terms and conditions of the applicable Altera Reference Design License Agreement.
By using this reference design file, you indicate your acceptance of such terms and
conditions between you and Altera Corporation.  In the event that you do not agree with
such terms and conditions, you may not use the reference design file. Please promptly
destroy any copies you have made.

This reference design file being provided on an "as-is" basis and as an accommodation
and therefore all warranties, representations or guarantees of any kind
(whether express, implied or statutory) including, without limitation, warranties of
merchantability, non-infringement, or fitness for a particular purpose, are
specifically disclaimed.  By making this reference design file available, Altera
expressly does not recommend, suggest or require that this reference design file be
used in combination with any other product not provided by Altera. */

#include <probe_com_cfg.h>
#include <probe_com.h>
#include <probe_rs232.h>
#include <probe_rs232c.h>

#include "fir.h"
#include "stdio.h"
#include "io.h"
#include "sys/alt_timestamp.h"
#include "temp.h"


short source_databuffer[DATA_BUFFER_SIZE];
short sw_destination_databuffer[DATA_BUFFER_SIZE];
short hw_destination_databuffer[DATA_BUFFER_SIZE];

float sw_proc_time;
float hw_proc_time;
float speedup_factor;

extern TEMP_STRUCT temperature_context;


/* Author:  JCJB
 * Date:  08/02/2006
 *
 * This software utilizes a C2H accelerated 15 tap symmetric FIR filter.  The filter
 * supports reconfiguration of the coefficients given that they are symmetric.  
 *
 * The filter has a sample rate of 1.0E7 and cutoff frequency of 1.25E6
 * The filter has the following features:
 * 		 low pass, hanning window, T = 15, coefficient width of 14 bits, divider of 2^15 */

int main()
{
  int i;
  int failure;
  unsigned long sw_time_1, sw_time_2, hw_time_1, hw_time_2;
  
  //enable the temperature sensor
  temp_sensor_init();

  //enable uCProbe communication
  ProbeCom_Init();
  ProbeRS232_Init(0);
  ProbeRS232_RxIntEn();

  // turn off the LEDS
  IOWR(LED_PIO_BASE,0,0xFF);

  printf("BeMicro SDK Lab: \n");
  printf("----------------\n\n");

  // Create the input data waveform
  printf("Creating buffer source data\n\n");
  for(i = 0; i < DATA_BUFFER_SIZE; i++)
  {
    source_databuffer[i] = input_data[i%INPUT_LENGTH];
  }

    if(alt_timestamp_start() < 0)
  {
    printf("Please add the high resolution timer to the timestamp timer setting in the syslib properties page.\n");
    return 0;
  }

  // record the value of the high resolution time-stamp timer at the entry and exit points of the software filter
  printf("Software filter is operating (please be patient)\n");
  sw_time_1 = alt_timestamp();
  FIR_SW(source_databuffer,
         DATA_BUFFER_SIZE,
         sw_destination_databuffer,
         T,
         coefficients[0],
         coefficients[1],
         coefficients[2],
         coefficients[3],
         coefficients[4],
         coefficients[5],
         coefficients[6],
         coefficients[7],
         DIVIDER_ORDER);
  sw_time_2 = alt_timestamp();
  printf("Software filter is done\n\n");



  // record the value of the high resolution time-stamp timer at the entry and exit points of the hardware filter
  printf("Hardware filter is operating\n");
  hw_time_1 = alt_timestamp();
  FIR_HW(source_databuffer,
         DATA_BUFFER_SIZE,
         hw_destination_databuffer,
         T,
         coefficients[0],
         coefficients[1],
         coefficients[2],
         coefficients[3],
         coefficients[4],
         coefficients[5],
         coefficients[6],
         coefficients[7],
         DIVIDER_ORDER);
  hw_time_2 = alt_timestamp();
  printf("Hardware filter is done\n\n");


  printf("Comparing hardware and software filter results\n");
  i = 0;
  failure = 0;
  do
  {
	//printf("hw_destination_databuffer[i] = %d sw_destination_databuffer[i] = %d\n", hw_destination_databuffer[i], sw_destination_databuffer[i]);
    if(hw_destination_databuffer[i] != sw_destination_databuffer[i])
    {
      failure = 1;
    }
  } while((failure != 1) && (++i < DATA_BUFFER_SIZE));

  if(failure == 0)
  {
    printf("The results match\n\n");
    sw_proc_time = ((double)(sw_time_2-sw_time_1))/((double)alt_timestamp_freq());
    hw_proc_time = ((double)(hw_time_2-hw_time_1))/((double)alt_timestamp_freq());
    speedup_factor = sw_proc_time/hw_proc_time;
    printf("Software processing time was: %f seconds\n", sw_proc_time);
    printf("Hardware processing time was: %f seconds\n", hw_proc_time);
    printf("Hardware speedup factor over the software implementation was: %.2f times\n\n", speedup_factor);
    printf("Processing times will also be reported by uC-Probe:\n");

  }
  else
  {
    printf("The results do not match");
    IOWR(LED_PIO_BASE,0,0x55);
  }

  return 1;
}
