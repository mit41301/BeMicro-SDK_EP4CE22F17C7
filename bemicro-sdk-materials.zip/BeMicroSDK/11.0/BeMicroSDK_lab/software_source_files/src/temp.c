#include "stdio.h"
#include "io.h"
#include "sys/alt_stdio.h"
#include "altera_avalon_spi_regs.h"
#include "alt_types.h"
#include "sys/alt_alarm.h"
#include "system.h"
#include "temp.h"

static alt_alarm temperature_alarm;
alt_u32 temperature_alarm_callback (void* context);

TEMP_STRUCT temperature_context;

/************************************************************************************************************************
*  Function: temp_sensor_init
*
*  Purpose:
*
*
*************************************************************************************************************************/

void temp_sensor_init()
{
	// use the system timer to scan the temp sensor at "SCAN_INTERVAL" intervals
	  alt_alarm_start (
	                    &temperature_alarm,                     // alt_alarm* alarm,
	                    (SCAN_INTERVAL / SYS_TIMER_PERIOD),    	// alt_u32 nticks,
	                    temperature_alarm_callback,             // alt_u32 (*callback) (void* context),
	                    &temperature_context            		// void* context
	                  );
}

/************************************************************************************************************************
*  Function: temperature_sensor_alarm_callback
*
*  Purpose:
*
*
*************************************************************************************************************************/

alt_u32 temperature_alarm_callback (void* context)
{
	int temp_data;
    float temperature_c, temperature_f;
    TEMP_STRUCT *temperature = context;

  // enable slave select mask
  IOWR_ALTERA_AVALON_SPI_SLAVE_SEL(TEMP_SENSE_SPI_BASE, 0x0001);

  // clear the status register
  IOWR_ALTERA_AVALON_SPI_STATUS(TEMP_SENSE_SPI_BASE, 0xFFFF);

  // assert the cs_n signal
  IOWR_ALTERA_AVALON_SPI_CONTROL(TEMP_SENSE_SPI_BASE, ALTERA_AVALON_SPI_CONTROL_SSO_MSK);

  // wait for transmitter to be ready
  while ((IORD_ALTERA_AVALON_SPI_STATUS(TEMP_SENSE_SPI_BASE) & ALTERA_AVALON_SPI_STATUS_TRDY_MSK) == 0) { }

  // receive first 16 bits from temp sensor by writing all ones (tx pin is open drain)
  IOWR_ALTERA_AVALON_SPI_TXDATA(TEMP_SENSE_SPI_BASE, 0xFFFF);

  // wait for receiver to be ready
  while ((IORD_ALTERA_AVALON_SPI_STATUS(TEMP_SENSE_SPI_BASE) & ALTERA_AVALON_SPI_STATUS_RRDY_MSK) == 0) { }

  // get temp conversion
  temp_data = IORD_ALTERA_AVALON_SPI_RXDATA(TEMP_SENSE_SPI_BASE);

  // wait for transmitter to be ready
    while ((IORD_ALTERA_AVALON_SPI_STATUS(TEMP_SENSE_SPI_BASE) & ALTERA_AVALON_SPI_STATUS_TRDY_MSK) == 0) { }

  // keep sensor in continuous acquisition mode
  IOWR_ALTERA_AVALON_SPI_TXDATA(TEMP_SENSE_SPI_BASE, 0x0000);

  // de-assert the cs_n signal
  IOWR_ALTERA_AVALON_SPI_CONTROL(TEMP_SENSE_SPI_BASE, 0x0000);

  //usleep(400000);

  temperature_c = (temp_data/4) * 0.03125;
  temperature_f = ((temperature_c * 9) / 5) + 32;

  temperature->value = temperature_f;

  return(SCAN_INTERVAL / SYS_TIMER_PERIOD);

  }
