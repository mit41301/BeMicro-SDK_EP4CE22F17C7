/* Legal Notice: (C)2010 Altera Corporation. All rights reserved.  Your */
/* use of Altera Corporation's design tools, logic functions and other */
/* software and tools, and its AMPP partner logic functions, and any */
/* output files any of the foregoing (including device programming or */
/* simulation files), and any associated documentation or information are */
/* expressly subject to the terms and conditions of the Altera Program */
/* License Subscription Agreement or other applicable license agreement, */
/* including, without limitation, that your use is for the sole purpose */
/* of programming logic devices manufactured by Altera and sold by Altera */
/* or its authorized distributors.  Please refer to the applicable */
/* agreement for further details. */

#ifdef CHAC_THIS
#else
#include "io.h"
#include "fir_hw.h"

#include <sys/alt_cache.h>

__inline__ void FIR_HW ( short *   input_data,
                long length,
                short *   output_data,
               unsigned char tap_length,
                short coefA,
                short coefB,
                short coefC,
                short coefD,
                short coefE,
                short coefF,
                short coefG,
                short coefH,
               unsigned char divide_order
             )
{
  IOWR_32DIRECT(ACCELERATOR_FIR_FIR_HW_MANAGED_INSTANCE_CPU_INTERFACE0_BASE, (4), (int) (input_data));
  IOWR_32DIRECT(ACCELERATOR_FIR_FIR_HW_MANAGED_INSTANCE_CPU_INTERFACE0_BASE, (8), (int) (length));
  IOWR_32DIRECT(ACCELERATOR_FIR_FIR_HW_MANAGED_INSTANCE_CPU_INTERFACE0_BASE, (12), (int) (output_data));
  IOWR_32DIRECT(ACCELERATOR_FIR_FIR_HW_MANAGED_INSTANCE_CPU_INTERFACE0_BASE, (16), (int) (tap_length));
  IOWR_32DIRECT(ACCELERATOR_FIR_FIR_HW_MANAGED_INSTANCE_CPU_INTERFACE0_BASE, (20), (int) (coefA));
  IOWR_32DIRECT(ACCELERATOR_FIR_FIR_HW_MANAGED_INSTANCE_CPU_INTERFACE0_BASE, (24), (int) (coefB));
  IOWR_32DIRECT(ACCELERATOR_FIR_FIR_HW_MANAGED_INSTANCE_CPU_INTERFACE0_BASE, (28), (int) (coefC));
  IOWR_32DIRECT(ACCELERATOR_FIR_FIR_HW_MANAGED_INSTANCE_CPU_INTERFACE0_BASE, (32), (int) (coefD));
  IOWR_32DIRECT(ACCELERATOR_FIR_FIR_HW_MANAGED_INSTANCE_CPU_INTERFACE0_BASE, (36), (int) (coefE));
  IOWR_32DIRECT(ACCELERATOR_FIR_FIR_HW_MANAGED_INSTANCE_CPU_INTERFACE0_BASE, (40), (int) (coefF));
  IOWR_32DIRECT(ACCELERATOR_FIR_FIR_HW_MANAGED_INSTANCE_CPU_INTERFACE0_BASE, (44), (int) (coefG));
  IOWR_32DIRECT(ACCELERATOR_FIR_FIR_HW_MANAGED_INSTANCE_CPU_INTERFACE0_BASE, (48), (int) (coefH));
  IOWR_32DIRECT(ACCELERATOR_FIR_FIR_HW_MANAGED_INSTANCE_CPU_INTERFACE0_BASE, (52), (int) (divide_order));
  alt_dcache_flush_all();
  /* Write 1 to address 0 starts the accelerator */
  IOWR_32DIRECT(ACCELERATOR_FIR_FIR_HW_MANAGED_INSTANCE_CPU_INTERFACE0_BASE,(0 * sizeof(int)),1);
  /* Poll. When read from address 0 returns 1, the accelerator is done */
  while(IORD_32DIRECT(ACCELERATOR_FIR_FIR_HW_MANAGED_INSTANCE_CPU_INTERFACE0_BASE,(0 * sizeof(int))) == 0)
  {}
}
#endif /* CHAC_THIS */




