/*Copyright � 2006 Altera Corporation. All rights reserved.  Altera products are
protected under numerous U.S. and foreign patents, maskwork rights, copyrights and
other intellectual property laws.  

This reference design file, and your use thereof, is subject to and governed by
the terms and conditions of the applicable Altera Reference Design License Agreement.
By using this reference design file, you indicate your acceptance of such terms and
conditions between you and Altera Corporation.  In the event that you do not agree with
such terms and conditions, you may not use the reference design file. Please promptly
destroy any copies you have made.

This reference design file being provided on an "as-is" basis and as an accommodation 
and therefore all warranties, representations or guarantees of any kind 
(whether express, implied or statutory) including, without limitation, warranties of 
merchantability, non-infringement, or fitness for a particular purpose, are 
specifically disclaimed.  By making this reference design file available, Altera
expressly does not recommend, suggest or require that this reference design file be
used in combination with any other product not provided by Altera. */

#define OUTPUT_BUFFER_LENGTH 1024 /* 32 bit words (keep it under 32768 bytes) */


/* Author:  JCJB
 * Date:  08/02/2006
 * 
 * This is the same implementation as the function FIR_HW */
 
void FIR_SW(short * input_data,  /* 15 bit values */
            long length,
            short * output_data,
            unsigned char tap_length,
            short coefA,
            short coefB,
            short coefC,
            short coefD,
            short coefE,
            short coefF,
            short coefG,
            short coefH,
            unsigned char divide_order)
{

  long adderA, adderB;
  short dataA, dataB, dataC, dataD, dataE, dataF, dataG, dataH;
  short dataI, dataJ, dataK, dataL, dataM, dataN, dataO, dataP;
  long termA, termB, termC, termD, termE, termF, termG, termH;
  long output_buffer[OUTPUT_BUFFER_LENGTH];
  unsigned short indexA, indexB;
  
  dataA = 0;
  dataB = 0;
  dataC = 0;
  dataD = 0;
  dataE = 0;
  dataF = 0;
  dataG = 0;
  dataH = 0;
  dataI = 0;
  dataJ = 0;
  dataK = 0;
  dataL = 0;
  dataM = 0;
  dataN = 0;
  dataO = 0;
  dataP = 0;
  

  
  do /* loop over entire data range */
  {
    indexA = 0;
    do /* will only reach this if length is greater than 1 */
    {
      /* This chain of assignments will act like a FIFO with a tap length of
       * one.  See the "Array Replacement" section of the "Optimizing Nios II
       * C2H Compiler Results" application note for more details */
      dataP = dataO;
      dataO = dataN;
      dataN = dataM;
      dataM = dataL;
      dataL = dataK;
      dataK = dataJ; 
      dataJ = ((tap_length & 0x1) == 0x1)? dataH : dataI; /* feed dataH if tap_length is an odd number */  
      dataI = ((tap_length & 0x1) == 0x1)? 0 : dataH; /* feed 0 if tap_length is an odd number */  
      dataH = dataG;
      dataG = dataF;
      dataF = dataE;
      dataE = dataD;
      dataD = dataC;
      dataC = dataB;
      dataB = dataA;
      dataA = *input_data++;

      /* calculate all the multiplication terms in parallel */
      termA = (dataA + dataP) * coefA;
      termB = (dataB + dataO) * coefB;
      termC = (dataC + dataN) * coefC;
      termD = (dataD + dataM) * coefD;
      termE = (dataE + dataL) * coefE;
      termF = (dataF + dataK) * coefF;
      termG = (dataG + dataJ) * coefG;
      termH = (dataH + dataI) * coefH;
    
      /* these are just temp variables so that all eight multiplication terms
       * are not added all in parallel (32 bit wide, 8 input adder can lead to
       * slow hardware) */
      adderA = (termA + termB) + (termC + termD);
      adderB = (termE + termF) + (termG + termH);
      
      /* storing the values to a temporary location to minimize SDRAM
       * non-sequential accesses */
      output_buffer[indexA] = adderA + adderB;
    } while ((--length > 0) & (++indexA < OUTPUT_BUFFER_LENGTH));


    /* copy output data buffer into main memory (with post scaling).  The scale
     * of the coefficients were a power of two so no multiplication is
     * needed. */
    indexB = 0;
    do
    {
      *output_data++ = (divide_order == 13)? (short)(output_buffer[indexB] >> 13):
                       (divide_order == 14)? (short)(output_buffer[indexB] >> 14):
                       (divide_order == 15)? (short)(output_buffer[indexB] >> 15):
                                             (short)(output_buffer[indexB] >> 16);
    } while (++indexB < indexA);
   
  } while(length > 0);
}
