The overall download zip file can be placed anywhere -BUT- the lab files must be unzipped to a path with no spaces in the name.
   (i.e. Like  C:\Altera\Trn\  and _NOT_ "My documents", for examples)

Just open the BeMicro SDK Embedded System SW Lab PDF manual and follow the instructions.



ISSUES TO AVOID
---------------

NOTE: The "Installation Utils & Issues to Avoid" folder is for the following issues that could arise:

- Micrium's uC/Probe tool - no GUI updates:
  uC/Probe will not update the GUI without the proper path entry for Quartus/bin. This occurs for a large
  percentage of laptops. 
  > See the word doc for the path fix.

- The original BeMicro workshop driver can interfere with the debugger launch (cannot launch GDB).
  > The uninstall executable should fix this (remove.exe)

- The "USB Blaster" driver installation may stop and ask for ftdibus.sys (or similar) file / disk.
  > The process for getting this handled is in the word doc.

- You may see no connection or a non-USB Blaster connection for JTAG connections (section 4.2).
  An old installation of an Altera ByteBlaster cable can cause this.  Mostly Arrow laptops.


OTHER 

- Windows 7 and Vista users:
  Must install the Altera tools as Administrator.  Must run the tools as administrator 
  (i.e. right-click on Nios II SBT tool icon and select "run as Administrator")

- BSP out of date Error:
  If in the main Embedded SW lab, you see "BSP out of date..." errors, you may need to correct your PC's clock/date.
  The timestamp mechanism for checking your BSP versus the hardware assumes you built your BSP before the hardware.

