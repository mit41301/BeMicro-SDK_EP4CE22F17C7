# TimeQuest SDC file for the mobile DDR SDRAM controller
# tailored for BeMicro SDK
# by Frank Storm and Harald Fluegel
# Arrow Central Europe GmbH

####################################################################################
# apply changes here if needed
####################################################################################

# physical data

# set the top level pin names
set pin(ext_clk) CLK_FPGA_50M
set mddrPin(A0) RAM_A0
set mddrPin(A1) RAM_A1
set mddrPin(A2) RAM_A2
set mddrPin(A3) RAM_A3
set mddrPin(A4) RAM_A4
set mddrPin(A5) RAM_A5
set mddrPin(A6) RAM_A6
set mddrPin(A7) RAM_A7
set mddrPin(A8) RAM_A8
set mddrPin(A9) RAM_A9
set mddrPin(A10) RAM_A10
set mddrPin(A11) RAM_A11
set mddrPin(A12) RAM_A12
set mddrPin(A13) RAM_A13
set mddrPin(BA0) RAM_BA0
set mddrPin(BA1) RAM_BA1
set mddrPin(CK_N) RAM_CK_N
set mddrPin(CK_P) RAM_CK_P
set mddrPin(CKE) RAM_CKE
set mddrPin(CS) RAM_CS_N
set mddrPin(WS) RAM_WS_N
set mddrPin(RAS) RAM_RAS_N
set mddrPin(CAS) RAM_CAS_N
set mddrPin(D0) RAM_D0
set mddrPin(D1) RAM_D1
set mddrPin(D2) RAM_D2
set mddrPin(D3) RAM_D3
set mddrPin(D4) RAM_D4
set mddrPin(D5) RAM_D5
set mddrPin(D6) RAM_D6
set mddrPin(D7) RAM_D7
set mddrPin(D8) RAM_D8
set mddrPin(D9) RAM_D9
set mddrPin(D10) RAM_D10
set mddrPin(D11) RAM_D11
set mddrPin(D12) RAM_D12
set mddrPin(D13) RAM_D13
set mddrPin(D14) RAM_D14
set mddrPin(D15) RAM_D15
set mddrPin(LDM) RAM_LDM
set mddrPin(UDM) RAM_UDM
set mddrPin(LDQS) RAM_LDQS
set mddrPin(UDQS) RAM_UDQS

# set the name of the PLL that sources the controller clock
set sysClock {uC|the_main_pll|sd1|pll7|clk[0]}

# set the hierarchical path to the memory controller
set mddrInstanceHierName uC:uC|mddr:the_mddr|mddr_ctrl:mddr

# timing values

# set external clock cycle time
set t(ext_clk) 20.0

# address and control inputs timing requirements

set t(IS) 1.1
set t(IH) 1.1

# DQ and DM timing requirement in relation ton DQS
set t(DS) 0.58
set t(DH) 0.58

# max. and min. access window of DQ in relation to CK_N/CK_P for CAS latency of 2
set t(ACmax) 6.5
set t(ACmin) 2.0

# max. and min. board delay
set t(board,max) 1.0
set t(board,min) 1.0

# specifiy board delays
set t(board,CK_N) 1.0
set t(board,CK_P) 1.0
set t(board,LDQS) 1.0
set t(board,UDQS) 1.0

####################################################################################
# don't change anything below this line
####################################################################################

create_clock -name ext_clk -period $t(ext_clk) [get_ports $pin(ext_clk)]
derive_pll_clocks -create_base_clocks 
create_generated_clock -divide_by 4 -invert -source $sysClock $mddrInstanceHierName|clk_n
create_generated_clock -divide_by 4 -source $sysClock $mddrInstanceHierName|clk_p
create_generated_clock -divide_by 4 -source $sysClock $mddrInstanceHierName|p34

# create the memory clocks

create_generated_clock -name mddr_clk -divide_by 1 -source $mddrInstanceHierName|clk_p \
        [get_ports $mddrPin(CK_P)]

create_generated_clock -name mddr_clk_n -divide_by 1 -source $mddrInstanceHierName|clk_n \
        [get_ports $mddrPin(CK_N)]

create_generated_clock -name mddr_udqs -divide_by 1 -source $mddrInstanceHierName|p34 \
        [get_ports $mddrPin(UDQS)]

create_generated_clock -name mddr_ldqs -divide_by 1 -source $mddrInstanceHierName|p34 \
        [get_ports $mddrPin(LDQS)]


# output path

foreach addressAndControlPin [list A0 A1 A2 A3 A4 A5 A6 A7 A8 A9 A10 A11 A12 A13 BA0 BA1 \
        CS WS RAS CAS CKE] {

    set_multicycle_path -setup -start -from [get_clocks $sysClock] \
            -to [get_ports $mddrPin($addressAndControlPin)] 2

    set_multicycle_path -hold -start -from [get_clocks $sysClock] \
            -to [get_ports $mddrPin($addressAndControlPin)] 1

    set_output_delay -min [expr $t(board,min) - $t(IH) - $t(board,CK_P)] -clock mddr_clk -add_delay \
            [get_ports $mddrPin($addressAndControlPin)]
    set_output_delay -max [expr $t(IS) + $t(board,max) - $t(board,CK_P)] -clock mddr_clk -add_delay \
            [get_ports $mddrPin($addressAndControlPin)]
}

foreach dataPin [list D0 D1 D2 D3 D4 D5 D6 D7 LDM] {
    # rising edge of QDS

    set_output_delay -min [expr $t(board,min) - $t(DH) - $t(board,LDQS)] -clock mddr_ldqs -add_delay \
            [get_ports $mddrPin($dataPin)]
    set_output_delay -max [expr $t(DS) + $t(board,max) - $t(board,LDQS)] -clock mddr_ldqs -add_delay \
            [get_ports $mddrPin($dataPin)]

    # falling edge of DQS

    set_output_delay -min [expr $t(DH) - $t(board,min) + $t(board,LDQS)] -clock mddr_ldqs -clock_fall -add_delay \
            [get_ports $mddrPin($dataPin)]
    set_output_delay -max [expr $t(DS) + $t(board,max) - $t(board,LDQS)] -clock mddr_ldqs -clock_fall -add_delay \
            [get_ports $mddrPin($dataPin)]
}

foreach dataPin [list D8 D9 D10 D11 D12 D13 D14 D15 UDM] {
    # rising edge of QDS

    set_output_delay -min [expr $t(board,min) -$t(DH) - $t(board,UDQS)] -clock mddr_udqs -add_delay \
            [get_ports $mddrPin($dataPin)]
    set_output_delay -max [expr $t(DS) + $t(board,max) - $t(board,UDQS)] -clock mddr_udqs -add_delay \
            [get_ports $mddrPin($dataPin)]

    # falling edge of DQS

    set_output_delay -min [expr $t(board,min) - $t(DH) - $t(board,UDQS)] -clock mddr_udqs -clock_fall -add_delay \
            [get_ports $mddrPin($dataPin)]
    set_output_delay -max [expr $t(DS) + $t(board,max) - $t(board,UDQS)] -clock mddr_udqs -clock_fall -add_delay \
            [get_ports $mddrPin($dataPin)]
}


# input path

foreach dataPin [list D0 D1 D2 D3 D4 D5 D6 D7 D8 D9 D10 D11 D12 D13 D14 D15] {

    set_input_delay -min [expr $t(ACmin) + $t(board,min) - $t(board,CK_P)] \
            -clock mddr_clk [get_ports $mddrPin($dataPin)]
    set_input_delay -max [expr $t(ACmax) + $t(board,max) - $t(board,CK_P)] \
            -clock mddr_clk [get_ports $mddrPin($dataPin)]

    set_input_delay -min [expr $t(ACmin) + $t(board,min) - $t(board,CK_N)] -add_delay \
            -clock mddr_clk_n [get_ports $mddrPin($dataPin)]
    set_input_delay -max [expr $t(ACmax) + $t(board,max) - $t(board,CK_N)] -add_delay \
            -clock mddr_clk_n [get_ports $mddrPin($dataPin)]

    set_multicycle_path -from [get_ports $mddrPin($dataPin)] -to [get_registers *] -setup -start 2
}

